var button3 = document.getElementById("btn-non-med");
button3.onclick = function(){
    console.log("pressed2");
    document.querySelector(".container").style.animationPlayState="running";
    setTimeout(function (){window.location.href = "Non-medicalPage.html";}, 1000);
};