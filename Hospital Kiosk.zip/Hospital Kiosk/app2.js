var button2 = document.getElementById("btn-med");
button2.onclick = function(){
    console.log("pressed");
    document.querySelector(".body-content2").style.animationPlayState="running";
    setTimeout(function (){window.location.href = "MedicalPage.html";}, 1000);
};

/*var button3 = document.getElementById("btn-non-med");
button3.onclick = function(){
    console.log("pressed2");
    document.querySelector(".body-content2").style.animationPlayState="running";
    setTimeout(function (){window.location.href = "Non-medicalPage.html";}, 1000);
};*/