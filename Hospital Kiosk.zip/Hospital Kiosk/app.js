var button = document.getElementById("button");
button.onclick = function(){
    document.querySelector(".body-content").style.animationPlayState="running";
    setTimeout(function (){window.location.href = "SignUp.html";}, 1000);
};


/*window.transitionToPage = function(href) {
    document.querySelector('container1').style.opacity = 0;
    setTimeout(function() { 
        window.location.href = href;
    }, 500)
},

document.addEventListener('DOMContentLoaded', function(event) {
    document.querySelector('container1').style.cssText = 'opacity:1;';
});*/